# Cultborn: Volume Three - Insectoids  
**Created by JK / JK Forge**  
*Version 1.0 – April 2025*

---

## 🙏 Thank You for Your Support!

Whether you grabbed the free pack or went for the premium edition, thanks for checking out the Cultborn series! I hope these assets help bring your game to life.

---

## 📝 Free Pack License

1. Use, edit, and modify the assets for commercial or non-commercial projects.  
2. Credit to **JK Forge** for commercial projects.  
3. Do not resell original or altered assets from this pack.

---

## 💎 Premium Pack License

1. Use, edit, and modify the assets for commercial or non-commercial projects.  
2. Credit to **JK Forge** is optional and much appreciated.  
3. Do not resell original or altered assets from this pack.

---

## 📬 Feedback and Support

If you enjoy the pack, I'd love to hear how you're using it! Feel free to share your projects or leave feedback.

**Follow for updates and new releases:**

- [Itch.io](https://jkforge.itch.io/)  
- [Reddit](https://www.reddit.com/user/JK-Forge/)  
- ✉️ Email: JKForge@mail.com
